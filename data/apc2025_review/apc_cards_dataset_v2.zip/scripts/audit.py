import json,glob,csv,os,re,collections,shutil,itertools
import openpyxl,xlsxwriter
from cas_table import check
S='..'; F=S+'/final'; A=S+'/package'; shutil.rmtree(A,ignore_errors=True)
for d in ['data/crops','audit','source_extraction_raw','scripts']: os.makedirs(f'{A}/{d}')
# ---- load final cards
cards=[]
for f in sorted(glob.glob(F+'/crops/*.json')): cards+=json.load(open(f))['cards']
cards.sort(key=lambda c:c['source_order'])
# ---- raw chunks
raw_cards=[];raw_rows=0;raw_seen=0
for f in sorted(glob.glob(S+'/chunks/chunk_*.json')):
    d=json.load(open(f));cs=d if isinstance(d,list) else d.get('cards')
    if cs is None: continue
    for c in cs:
        n=sum(len(t['rows']) for t in c.get('tables',[]));raw_rows+=n;raw_seen+=c.get('rows_seen') or 0
        raw_cards.append((os.path.basename(f),c['crop_id'],c['pest_name_ar'],n,c.get('rows_seen')))
# ---- flat table
FLAT=[]
for c in cards:
    pg=(c['printed_pages'] or [None])
    for ti,t in enumerate(c['tables']):
        for r in t['recommendations']:
            for oi,o in enumerate(r['options']):
                acts=' + '.join(f"{x['name_en']} {x['pct'] if x['pct'] is not None else '?'}%" for x in r['actives'])
                cas=' + '.join(x['cas'] or 'NO-CAS' for x in r['actives'])
                FLAT.append(dict(card_id=c['id'],source_order=c['source_order'],crop_id=c['crop_id'],part=c['part'],pest_ar=c['pest_name_ar'],pest_group_ar=c['pest_group_ar'],
                  pest_type=c['pest_type'],printed_page_first=pg[0],printed_pages=','.join(map(str,c['printed_pages'] or [])),pdf_page_first=(pg[0]+13 if pg[0] else None),
                  subheading_ar=t['subheading_ar'],rec_id=r['id'],actives_and_conc=acts,cas=cas,formulation=f"{r['formulation_type'] or ''} {r['formulation_total_pct'] if r['formulation_total_pct'] is not None else ''}".strip(),
                  rate_text_ar=o['rate_text_ar'],phi_days=json.dumps(o['phi_days'],ensure_ascii=False) if isinstance(o['phi_days'],(list,dict)) else o['phi_days'],who=o['who_class'],
                  mrl_epa_eu_codex=' ; '.join(f"{m['epa']}|{m['eu']}|{m['codex']}" for m in o['mrl']),footnote_ref=o['footnote_ref'],uncertain=o['uncertain'],row_note=o['note'],_card=c,_rec=r,_opt=o))
COLS=[k for k in FLAT[0] if not k.startswith('_')]
with open(A+'/data/recommendations_flat.csv','w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=COLS,extrasaction='ignore');w.writeheader();w.writerows(FLAT)
# ---- actives with verification
acts=json.load(open(F+'/actives.json'))['actives']
prev={a['cas']:a for a in json.load(open(S+'/out/actives.json'))['actives']}
this_session={'1344-73-6':['https://www.fbn.com/api/store/market/documents/sds/basic-copper-sulfate-technical.pdf'],
 '1332-40-7':['https://sitem.herts.ac.uk/aeru/ppdb/en/Reports/177.htm'],'22259-30-9':['https://en.wikipedia.org/wiki/Formetanate'],'23422-53-9':['https://en.wikipedia.org/wiki/Formetanate'],
 '1820573-27-0':['https://m.chemicalbook.com/CASEN_1820573-27-0.htm']}
for a in acts:
    a['cas_verification']={}
    if a['cas'] and a['cas'] in prev: a['cas_verification']=dict(level='verified_secondary_source',sources=prev[a['cas']]['cas_check']['sources'],note='مصادر ثانوية (مواقع تجارية/مرجعية) وليست قاعدة رسمية')
    elif a['cas'] and a['cas'] in this_session: a['cas_verification']=dict(level='verified_secondary_source',sources=this_session[a['cas']],note='جُلبت الصفحة وقُرئ الرقم فيها')
    elif a['cas']: a['cas_verification']=dict(level='needs_verification',sources=[],note='الرقم معيَّن من المعرفة المرجعية للنموذج؛ خانة الفحص صحيحة (شرط لازم لا كافٍ)؛ لم يُطابق مع مصدر خارجي')
    else: a['cas_verification']=dict(level='no_cas_assigned',sources=[],note=a['status'])
    a['source_vs_reference']={'name_as_printed_in_book':a['raw_spellings'],'name_en_canonical_(external_reference)':a['name_en']}
json.dump(dict(dataset='actives',actives=acts),open(A+'/data/actives.json','w'),ensure_ascii=False,indent=1)
for f in glob.glob(F+'/crops/*.json'): shutil.copy(f,A+'/data/crops/')
shutil.copy(F+'/appendix7_minor_crops.json',A+'/data/')
for f in glob.glob(S+'/chunks/chunk_*.json'): shutil.copy(f,A+'/source_extraction_raw/')
for f in ['merge/cas_table.py','merge/build.py','merge/finalize.py','merge/audit.py','spec/SPEC.md','spec/crops.tsv','parser/notes_dict.json']:
    shutil.copy(f'{S}/{f}',A+'/scripts/')
# ---- Excel
XL=A+'/data/recommendations_audit.xlsx'
wb=xlsxwriter.Workbook(XL);hdr=wb.add_format({'bold':True,'bg_color':'#d9ead3','border':1});
def sheet(name,cols,rows):
    ws=wb.add_worksheet(name[:31]);ws.freeze_panes(1,0)
    for j,cn in enumerate(cols): ws.write(0,j,cn,hdr);ws.set_column(j,j,max(12,min(40,len(cn)+6)))
    for i,r in enumerate(rows,1):
        for j,cn in enumerate(cols):
            v=r.get(cn) if isinstance(r,dict) else r[j]
            if isinstance(v,(list,dict)): v=json.dumps(v,ensure_ascii=False)
            ws.write(i,j,v)
    return ws
sheet('recommendations',COLS,FLAT)
cardrows=[dict(card_id=c['id'],source_order=c['source_order'],crop_id=c['crop_id'],part=c['part'],pest_ar=c['pest_name_ar'],pest_group_ar=c['pest_group_ar'],pest_type=c['pest_type'],printed_pages=c['printed_pages'],
  appearance_ar=c['appearance_ar'],onset_ar=c['onset_ar'],control_timing_ar=c['control_timing_ar'],guidance_ar=c['guidance_ar'],rows=sum(t['source_rows'] for t in c['tables']),uncertain=c['uncertain'],notes=c['notes']) for c in cards]
sheet('cards',list(cardrows[0]),cardrows)
sheet('actives_cas',['cas','name_en','raw_spellings','status','cas_candidate','cas_alt','n_rows','verification_level','verification_sources','verification_note'],
  [dict(cas=a['cas'],name_en=a['name_en'],raw_spellings=a['raw_spellings'],status=a['status'],cas_candidate=a.get('cas_candidate'),cas_alt=a['cas_alt'],n_rows=a['n_rows'],
        verification_level=a['cas_verification']['level'],verification_sources=a['cas_verification']['sources'],verification_note=a['cas_verification']['note']) for a in acts])
# ---- audits
rep={}
# counts
final_opts=len(FLAT)
rd=list(csv.DictReader(open(A+'/data/recommendations_flat.csv',encoding='utf-8-sig')))
fin_json_opts=0;fin_json_cards=0
for f in glob.glob(A+'/data/crops/*.json'):
    for c in json.load(open(f))['cards']:
        fin_json_cards+=1;fin_json_opts+=sum(len(r['options']) for t in c['tables'] for r in t['recommendations'])
rep['counts']=dict(raw_cards=len(raw_cards),raw_rows=raw_rows,raw_rows_seen_sum=raw_seen,json_cards=fin_json_cards,json_rows_options=fin_json_opts,csv_rows=len(rd),excel_rows='(set below)',
  json_recommendations_grouped=sum(len(t['recommendations']) for c in cards for t in c['tables']))
card_diff=[dict(chunk=a,crop=b,pest=c,rows_in_tables=d,rows_seen_declared=e) for a,b,c,d,e in raw_cards if d!=e]
# potential duplicates
def rowkey(x): return (x['crop_id'],x['pest_ar'],x['actives_and_conc'],x['formulation'],x['rate_text_ar'],str(x['phi_days']),x['who'],x['mrl_epa_eu_codex'])
g=collections.defaultdict(list)
for x in FLAT: g[rowkey(x)].append(x)
dups_same=[]; dups_cross=[]
for k,v in g.items():
    if len(v)>1:
        for x in v:
            rec=dict(crop_id=x['crop_id'],pest_ar=x['pest_ar'],card_id=x['card_id'],printed_pages=x['printed_pages'],actives_and_conc=x['actives_and_conc'],formulation=x['formulation'],rate_text_ar=x['rate_text_ar'],phi_days=x['phi_days'],group_size=len(v))
            (dups_same if len({y['card_id'] for y in v})==1 else dups_cross).append(rec)
cp=collections.Counter((c['crop_id'],c['pest_name_ar']) for c in cards)
dup_cards=[dict(crop_id=k[0],pest_ar=k[1],n_cards=n,card_ids=[c['id'] for c in cards if (c['crop_id'],c['pest_name_ar'])==k],printed_pages=[c['printed_pages'] for c in cards if (c['crop_id'],c['pest_name_ar'])==k]) for k,n in cp.items() if n>1]
# uncertain
unc=[]
for c in cards:
    if c['uncertain']: unc.append(dict(level='card',crop_id=c['crop_id'],pest_ar=c['pest_name_ar'],card_id=c['id'],printed_pages=c['printed_pages'],actives='',reason=c['notes']))
for x in FLAT:
    if x['uncertain']: unc.append(dict(level='row',crop_id=x['crop_id'],pest_ar=x['pest_ar'],card_id=x['card_id'],printed_pages=x['printed_pages'],actives=x['actives_and_conc'],reason=x['row_note'] or '(لا سبب مكتوب في الملاحظة؛ راجع ملاحظة البطاقة)'))
# missing/conflicting
miss=[]
for x in FLAT:
    o=x['_opt'];r=x['_rec'];base=dict(crop_id=x['crop_id'],pest_ar=x['pest_ar'],card_id=x['card_id'],printed_pages=x['printed_pages'],actives=x['actives_and_conc'])
    if any(a['pct'] is None for a in r['actives']): miss.append(dict(base,field='concentration',issue='تركيز مادة فعالة غير مطبوع/غير محدد'))
    if not r['formulation_type']: miss.append(dict(base,field='formulation_type',issue='نوع المستحضر غير موجود'))
    if r['formulation_total_pct'] is None: miss.append(dict(base,field='formulation_total_pct',issue='نسبة المستحضر غير موجودة'))
    if not o['rate_text_ar'] and not o['rate_parts']: miss.append(dict(base,field='rate',issue='معدل الاستخدام غير موجود'))
    if o['phi_days'] is None: miss.append(dict(base,field='phi_days',issue='فترة الأمان فارغة (أو أكثر من قيمة في الأصل بحسب الملاحظة)'))
    if not o['who_class']: miss.append(dict(base,field='who',issue='تصنيف WHO فارغ'))
    if not o['mrl']: miss.append(dict(base,field='mrl',issue='قيم MRL غير موجودة'))
    elif len(o['mrl'])!=len(r['actives']): miss.append(dict(base,field='mrl',issue=f"عدد أسطر MRL ({len(o['mrl'])}) ≠ عدد المواد ({len(r['actives'])})"))
    if r['formulation_total_pct'] and r['actives'] and all(a['pct'] is not None for a in r['actives']):
        tot=sum(a['pct'] for a in r['actives'])
        if abs(tot-r['formulation_total_pct'])>0.6: miss.append(dict(base,field='concentration_sum',issue=f"مجموع تراكيز المواد {tot} ≠ نسبة المستحضر {r['formulation_total_pct']} (قد يكون من الأصل المطبوع)"))
for c in cards:
    for t in c['tables']:
        for r in t['recommendations']:
            if len(r['who_classes'])>1: miss.append(dict(crop_id=c['crop_id'],pest_ar=c['pest_name_ar'],card_id=c['id'],printed_pages=c['printed_pages'],actives=' + '.join(a['name_en'] for a in r['actives']),field='who',issue='تصنيف WHO مختلف بين صفوف نفس المادة/المستحضر: '+'/'.join(r['who_classes'])+' (قد يعود لاختلاف المنتجات؛ يلزم تدقيق الأصل)'))
    if c['pest_group_ar'] is None: miss.append(dict(crop_id=c['crop_id'],pest_ar=c['pest_name_ar'],card_id=c['id'],printed_pages=c['printed_pages'],actives='',field='pest_group',issue='مجموعة الآفة فارغة'))
# spelling
spell=[]
for a in acts:
    for sp in a['raw_spellings']:
        if sp!=a['name_en']: spell.append(dict(lang='en',where='active name',original_in_book=sp,suggested=a['name_en'],reason='اختلاف هجاء/صياغة عن الاسم الشائع؛ وُحّد عبر CAS وبقي الأصل محفوظًا',needs_human_review=('نعم' if a['status'] in('printed_name_unmatched_review',) else 'تأكيد سريع')))
AR=re.compile(r'[؀-ۿ]+')
fields=[]
for c in cards:
    for k in ('pest_name_ar','appearance_ar','onset_ar','control_timing_ar','guidance_ar'):
        if c.get(k): fields.append((c['id'],k,c[k]))
words=collections.Counter(w for _,_,t in fields for w in AR.findall(t))
def lev1(a,b):
    if a==b or abs(len(a)-len(b))>1: return False
    if len(a)==len(b): return sum(x!=y for x,y in zip(a,b))==1
    s,l=(a,b) if len(a)<len(b) else (b,a)
    return any(l[:i]+l[i+1:]==s for i in range(len(l)))
def internal(a,b):
    p=0
    while p<min(len(a),len(b)) and a[p]==b[p]: p+=1
    q=0
    while q<min(len(a),len(b))-p and a[-1-q]==b[-1-q]: q+=1
    return p>=2 and q>=2
common=[w for w,n in words.items() if n>=4 and len(w)>=4]
byfirst=collections.defaultdict(list)
for w in common: byfirst[len(w)].append(w)
seen=set()
for cid,k,t in fields:
    for w in set(AR.findall(t)):
        if words[w]<=1 and len(w)>=4:
            for L in (len(w)-1,len(w),len(w)+1):
                for cand in byfirst.get(L,[]):
                    if lev1(w,cand) and internal(w,cand) and (w,cand) not in seen:
                        seen.add((w,cand));spell.append(dict(lang='ar',where=f'{cid}:{k}',original_in_book=w,suggested=cand,reason=f'مرشّح منخفض الثقة: كلمة وحيدة تبعد حرفًا واحدًا عن كلمة شائعة ({words[cand]} مرة)؛ قد تكون خطأ طباعيًا في الكتاب أو في القراءة',needs_human_review='نعم'))
for cid,k,t in fields:
    if '�' in t: spell.append(dict(lang='ar',where=f'{cid}:{k}',original_in_book=t[:60],suggested='',reason='حرف استبدال U+FFFD',needs_human_review='نعم'))
    if re.search(r'  +',t): spell.append(dict(lang='ar',where=f'{cid}:{k}',original_in_book=re.search(r'.{0,15}  +.{0,15}',t).group(0),suggested='مسافة واحدة',reason='مسافات مزدوجة',needs_human_review='لا'))
typo_notes=[]
for c in cards:
    s=' | '.join(filter(None,[c['notes']]+[x['note'] for t in c['tables'] for r in t['recommendations'] for x in r['options']]))
    for m in re.finditer(r'[^|.؛]*(?:خطأ|طباع|هجاء|كما طُبع|كما طبع)[^|.؛]*',s): typo_notes.append(dict(lang='ar/en',where=c['id'],original_in_book='(انظر النص)',suggested='',reason=m.group(0).strip()[:300],needs_human_review='نعم'))
spell+=typo_notes
rep['n']=dict(card_diff=len(card_diff),dups_same_card=len(dups_same),dups_cross_card=len(dups_cross),dup_cards=len(dup_cards),uncertain=len(unc),missing=len(miss),spell=len(spell))
sheet('uncertain',['level','crop_id','pest_ar','card_id','printed_pages','actives','reason'],unc)
sheet('missing_conflicts',['crop_id','pest_ar','card_id','printed_pages','actives','field','issue'],miss)
sheet('dups_same_card',list(dups_same[0]) if dups_same else ['none'],dups_same)
sheet('dups_cross_card',list(dups_cross[0]) if dups_cross else ['none'],dups_cross)
sheet('dup_cards',['crop_id','pest_ar','n_cards','card_ids','printed_pages'],dup_cards)
sheet('spelling',['lang','where','original_in_book','suggested','reason','needs_human_review'],spell)
a7=json.load(open(F+'/appendix7_minor_crops.json'))
wb.close()
xl=openpyxl.load_workbook(XL,read_only=True)
rep['counts']['excel_rows']=xl['recommendations'].max_row-1
rep['counts']['excel_cards']=xl['cards'].max_row-1
rep['counts']['match_all']=len({rep['counts']['raw_rows'],rep['counts']['json_rows_options'],rep['counts']['csv_rows'],rep['counts']['excel_rows']})==1
json.dump(dict(rep=rep,card_diff=card_diff,uncertain=unc,missing=miss,dups_same=dups_same,dups_cross=dups_cross,dup_cards=dup_cards,spelling=spell),open(A+'/audit/audit_data.json','w'),ensure_ascii=False,indent=1)
print(json.dumps(rep,ensure_ascii=False,indent=1));print(collections.Counter(m['field'] for m in miss));print(collections.Counter(a['cas_verification']['level'] for a in acts))
