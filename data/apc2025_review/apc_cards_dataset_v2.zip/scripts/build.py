import json,glob,re,collections,os,sys
from cas_table import *
ALT={"Formetanate":["23422-53-9"],"Copper oxychloride":["1332-65-6"],"Iodosulfuron-methyl-sodium":[],"Copper sulfate (tribasic)":["12527-76-3"]}
BIO={"Bacillus amyloliquefaciens FZB24","Bacillus amyloliquefaciens MBI 600","Bacillus megaterium","Bacillus subtilis","Trichoderma album","Trichoderma asperellum","Trichoderma viride"}
def act_info(raw):
    c,typo=resolve(raw)
    if c and c.startswith("__REVIEW__"):
        return dict(name_en=c[10:],cas=None,status="printed_name_unmatched_review",spelling_variant=True,cas_candidate=CAND.get(c[10:]))
    if c is None: return dict(name_en=raw,cas=None,status="unresolved",spelling_variant=False)
    if c in BIO: return dict(name_en=c,cas=None,status="microbial_no_cas",spelling_variant=bool(typo))
    if c=="Copper Complex" or c=="Copper complex": return dict(name_en=c,cas=None,status="ambiguous_no_cas",spelling_variant=bool(typo))
    cas=C[c]
    st="cas_assigned_checkdigit_ok"
    if typo: st="variant_mapped_checkdigit_ok"
    if raw=="Pyroxsulfone": st="variant_mapped_by_same_product_in_book"
    return dict(name_en=c,cas=cas,status=st,spelling_variant=bool(typo))
import re as _re
def scrub(s):
    if not s: return s
    if _re.search(r'دوفيكس|سيرفر|رقم التسجيل|ويب سوبر|ساكورا',s):
        parts=[p for p in _re.split(r'(?<=[.؛])\s*',s) if p and not _re.search(r'دوفيكس|سيرفر|رقم التسجيل|ويب سوبر|ساكورا',p)]
        return ' '.join(parts) or None
    return s
cards=[];actives={}
for f in sorted(glob.glob('../chunks/chunk_*.json')):
    d=json.load(open(f));cs=d if isinstance(d,list) else d.get('cards')
    if cs is None: continue
    for i,c in enumerate(cs):
        c['_src']=os.path.basename(f);c['_i']=i;cards.append(c)
issues=[]
def conservative(phis):
    v=[p for p in phis if isinstance(p,(int,float))]
    return max(v) if v else None
out_cards=[]
for c in cards:
    tabs=[]
    for t in c.get('tables',[]):
        groups=collections.OrderedDict()
        for r in t['rows']:
            acts=[]
            for a in r['actives']:
                inf=act_info(a['name'])
                key=inf['cas'] or ('NOCAS:'+inf['name_en'])
                acts.append(dict(key=key,name_en=inf['name_en'],cas=inf['cas'],pct=a.get('pct'),raw=a['name']))
                ent=actives.setdefault(key,dict(cas=inf['cas'],name_en=inf['name_en'],status=inf['status'],cas_candidate=inf.get('cas_candidate'),cas_alt=ALT.get(inf['name_en'],[]),raw_spellings=set(),n_rows=0))
                ent['raw_spellings'].add(a['name']);ent['n_rows']+=1
            gk=(tuple(sorted((a['key'],a['pct']) for a in acts)),r.get('form'),r.get('form_pct'))
            mrl=r.get('mrl') or []
            if mrl and len(mrl)!=len(acts): issues.append(('mrl_len',c['crop_id'],c['pest_name_ar'],[a['name_en'] for a in acts]))
            opt=dict(rate_text_ar=r.get('rate_text_ar'),rate_parts=r.get('rate_parts'),phi_days=r.get('phi_days'),
                     mrl=[dict(cas=(acts[j]['cas'] if j<len(acts) else None),epa=m.get('epa'),eu=m.get('eu'),codex=m.get('codex')) for j,m in enumerate(mrl)],
                     who_class=r.get('who'),footnote_ref=r.get('footnote_ref'),uncertain=bool(r.get('uncertain')),note=scrub(r.get('notes')))
            g=groups.setdefault(gk,dict(actives=[dict(cas=a['cas'],name_en=a['name_en'],pct=a['pct'],name_as_printed=a['raw']) for a in acts],
                       formulation_type=r.get('form'),formulation_total_pct=r.get('form_pct'),options=[],source_row_count=0))
            g['options'].append(opt);g['source_row_count']+=1
        recs=[]
        for k,(g) in enumerate(groups.values(),1):
            g['phi_conservative']=conservative([o['phi_days'] if not isinstance(o['phi_days'],list) else conservative(o['phi_days']) for o in g['options']])
            g['who_classes']=sorted({o['who_class'] for o in g['options'] if o['who_class']});g['id']=f"r{k}";recs.append(g)
        tabs.append(dict(subheading_ar=t.get('subheading_ar'),recommendations=recs,source_rows=len(t['rows'])))
    nc=dict(crop_id=c['crop_id'],part=c.get('part'),pest_name_ar=c.get('pest_name_ar'),pest_group_ar=c.get('pest_group_ar'),pest_type=c.get('pest_type'),
        printed_pages=c.get('printed_pages'),appearance_ar=c.get('appearance_ar'),onset_ar=c.get('onset_ar'),control_timing_ar=c.get('control_timing_ar'),
        guidance_ar=c.get('guidance_ar'),extra_sections=c.get('extra_sections'),examples_ar=c.get('examples_ar'),footnotes=c.get('footnotes'),
        tables=tabs,uncertain=bool(c.get('uncertain')),notes=scrub(c.get('notes')),_src=c['_src'])
    out_cards.append(nc)
json.dump(dict(cards=out_cards,issues=issues),open('merged_raw.json','w'),ensure_ascii=False)
for v in actives.values(): v['raw_spellings']=sorted(v['raw_spellings'])
json.dump(actives,open('actives_raw.json','w'),ensure_ascii=False,indent=1)
print(len(out_cards),sum(t['source_rows'] for c in out_cards for t in c['tables']),sum(len(t['recommendations']) for c in out_cards for t in c['tables']),len(actives))
print(collections.Counter(v['status'] for v in actives.values()))
print(collections.Counter(i[0] for i in issues))
