# canonical -> (CAS or None, confidence 'high'|'check'|'none')
C={
"1,3-Dichloropropene":"542-75-6","8-Hydroxyquinoline sulfate":"134-31-6","Abamectin":"71751-41-2","Acequinocyl":"57960-19-7",
"Acetamiprid":"135410-20-7","Afidopyropen":"915972-17-7","Alpha-cypermethrin":"67375-30-8","Aluminium phosphide":"20859-73-8",
"Ametoctradin":"865318-97-4","Amisulbrom":"348635-87-0","Azadirachtin":"11141-17-6","Azoxystrobin":"131860-33-8",
"Bacillus thuringiensis":"68038-71-1","Benalaxyl":"71626-11-4","Bentazone":"25057-89-0","Benthiavalicarb-isopropyl":"177406-68-7",
"Beta-cyfluthrin":"1820573-27-0","Bifenazate":"149877-41-8","Bifenthrin":"82657-04-3","Bistrifluron":"201593-84-2",
"Bordeaux mixture":"8011-63-0","Boscalid":"188425-85-6","Bromadiolone":"28772-56-7","Bromoxynil":"1689-84-5",
"Bromoxynil octanoate":"1689-99-2","Bupirimate":"41483-43-6","Buprofezin":"69327-76-0","CO2":"124-38-9","Cadusafos":"95465-99-9",
"Captan":"133-06-2","Carboxin":"5234-68-4","Carfentrazone-ethyl":"128639-02-1","Chlorantraniliprole":"500008-45-7",
"Chlorfenapyr":"122453-73-0","Chlorfluazuron":"71422-67-8","Chloropicrin":"76-06-2","Chlorothalonil":"1897-45-6",
"Chromafenozide":"143807-66-3","Citronella oil":"8000-29-1","Clethodim":"99129-21-2","Clodinafop-propargyl":"105512-06-9",
"Clofentezine":"74115-24-5","Clothianidin":"210880-92-5","Copper sulfate":"7758-98-7","Copper sulfate pentahydrate":"7758-99-8",
"Copper sulfate (tribasic)":"1344-73-6","Copper hydroxide":"20427-59-2","Copper oxychloride":"1332-40-7",
"Cyantraniliprole":"736994-63-1","Cyazofamid":"120116-88-3","Cycloxydim":"101205-02-1","Cyflufenamid":"180409-60-3",
"Cyflumetofen":"400882-07-7","Cymoxanil":"57966-95-7","Cypermethrin":"52315-07-8","Cyproconazole":"94361-06-5",
"Cyprodinil":"121552-61-2","Cyromazine":"66215-27-8","Dazomet":"533-74-4","Deltamethrin":"52918-63-5","Desmedipham":"13684-56-5",
"Dicamba":"1918-00-9","Difenoconazole":"119446-68-3","Diflubenzuron":"35367-38-5","Diflufenican":"83164-33-4",
"Dimethomorph":"110488-70-5","Dimethyl disulfide":"624-92-0","Dinotefuran":"165252-70-0","Dithianon":"3347-22-6","Dodine":"2439-10-3",
"Emamectin benzoate":"155569-91-8","Esfenvalerate":"66230-04-4","Ethofumesate":"26225-79-6","Ethoprophos":"13194-48-4",
"Etofenprox":"80844-07-1","Etoxazole":"153233-91-1","Famoxadone":"131807-57-3","Fenazaquin":"120928-09-8","Fenhexamid":"126833-17-8",
"Fenoxaprop-P-ethyl":"71283-80-2","Fenpropathrin":"39515-41-8","Fenpyrazamine":"473798-59-3","Fenpyroximate":"134098-61-6",
"Flometoquin":"875775-74-9","Flonicamid":"158062-67-0","Florasulam":"145701-23-1","Fluazifop-P-butyl":"79241-46-6",
"Fluazinam":"79622-59-6","Flubendiamide":"272451-65-7","Fludioxonil":"131341-86-1","Flufenacet":"142459-58-3",
"Flufenoxuron":"101463-69-8","Flumetsulam":"98967-40-9","Fluopicolide":"239110-15-7","Fluopyram":"658066-35-4",
"Fluoxastrobin":"361377-29-9","Flupyradifurone":"951659-40-8","Flutianil":"304900-25-2","Flutolanil":"66332-96-5",
"Flutriafol":"76674-21-0","Fluxapyroxad":"907204-31-3","Folpet":"133-07-3","Foramsulfuron":"173159-57-4","Formetanate":"22259-30-9",
"Fosetyl-aluminium":"39148-24-8","Fosthiazate":"98886-44-3","Halauxifen-methyl":"943831-98-9","Haloxyfop-P-methyl":"72619-32-0",
"Hexaflumuron":"86479-06-3","Hexythiazox":"78587-05-0","Hymexazol":"10004-44-1","Imazalil":"35554-44-0","Imicyafos":"140163-89-9",
"Imidacloprid":"138261-41-3","Iminoctadine tris(albesilate)":"169202-06-6","Indoxacarb":"144171-61-9",
"Iodosulfuron-methyl-sodium":"144550-36-7","Iodosulfuron-methyl":"144550-06-1","Iprovalicarb":"140923-17-7","Isoprothiolane":"50512-35-1",
"Jasmine oil":"8022-96-6","Jojoba oil":"61789-91-1","Kasugamycin":"6980-18-3","Kresoxim-methyl":"143390-89-0",
"Lambda-cyhalothrin":"91465-08-6","Lenacil":"2164-08-1","Lufenuron":"103055-07-8","MCPA-isooctyl":"26544-20-7","MCPA-sodium":"3653-48-3",
"Magnesium phosphide":"12057-74-8","Mancozeb":"8018-01-7","Mandipropamid":"374726-62-2","Mefenpyr-diethyl":"135590-91-9",
"Mefentrifluconazole":"1417782-03-6","Mesosulfuron-methyl":"208465-21-8","Metaflumizone":"139968-49-3","Metalaxyl":"57837-19-1",
"Metalaxyl-M":"70630-17-0","Metaldehyde":"108-62-3","Metam sodium":"137-42-8","Metamitron":"41394-05-2","Methoxyfenozide":"161050-58-4",
"Methyl eugenol":"93-15-2","Metiram":"9006-42-2","Metrafenone":"220899-03-6","Metsulfuron-methyl":"74223-64-6","Milbemectin":"51596-10-2",
"Mineral oil":"8042-47-5","Myclobutanil":"88671-89-0","Novaluron":"116714-46-6","Orange oil":"8028-48-6","Oxamyl":"23135-22-0",
"Oxathiapiprolin":"1003318-67-9","Oxine-copper":"10380-28-6","Oxyfluorfen":"42874-03-3","Penconazole":"66246-88-6",
"Pencycuron":"66063-05-6","Pendimethalin":"40487-42-1","Penflufen":"494793-67-8","Penthiopyrad":"183675-82-3","Phenmedipham":"13684-63-4",
"Phosphorous acid salts":"13598-36-2","Phosmet":"732-11-6","Phosphine":"7803-51-2","Picoxystrobin":"117428-22-5","Pinoxaden":"243973-20-8",
"Pirimicarb":"23103-98-2","Prochloraz":"67747-09-5","Propamocarb hydrochloride":"25606-41-1","Propiconazole":"60207-90-1",
"Proquinazid":"189278-12-4","Prosulfocarb":"52888-80-9","Pydiflumetofen":"1228284-64-7","Pyraclostrobin":"175013-18-0",
"Pyraflufen-ethyl":"129630-19-9","Pyridaben":"96489-71-3","Pyridalyl":"179101-81-6","Pyrimethanil":"53112-28-0","Pyriproxyfen":"95737-68-1",
"Pyroxasulfone":"447399-55-5","Pyroxsulam":"422556-08-9","Quizalofop-P-ethyl":"100646-51-3","S-metolachlor":"87392-12-9",
"Spinetoram":"935545-74-7","Spinosad":"168316-95-8","Spirodiclofen":"148477-71-8","Spiromesifen":"283594-90-1","Spirotetramat":"203313-25-1",
"Spiroxamine":"118134-30-8","Streptomycin sulfate":"3810-74-0","Sulfosulfuron":"141776-32-1","Sulfoxaflor":"946578-00-3","Sulfur":"7704-34-9",
"Tebuconazole":"107534-96-3","Tebufenozide":"112410-23-8","Tebufenpyrad":"119168-77-3","Teflubenzuron":"83121-18-0","Tetraconazole":"112281-77-3",
"Thiabendazole":"148-79-8","Thiamethoxam":"153719-23-4","Thiencarbazone-methyl":"317815-83-1","Thifluzamide":"130000-40-7",
"Thiocyclam hydrogen oxalate":"31895-22-4","Thiophanate-methyl":"23564-05-8","Tolclofos-methyl":"57018-04-9","Tolfenpyrad":"129558-76-5",
"Tralkoxydim":"87820-88-0","Triadimenol":"55219-65-3","Tribenuron-methyl":"101200-48-0","Tricyclazole":"41814-78-2",
"Trifloxystrobin":"141517-21-7","Triflumizole":"68694-11-1","Triflumuron":"64628-44-0","Triticonazole":"131983-72-7",
"Zeta-cypermethrin":"52315-07-8","Zinc phosphide":"1314-84-7","Zoxamide":"156052-68-5",
}
NULLCAS=["Bacillus amyloliquefaciens FZB24","Bacillus amyloliquefaciens MBI 600","Bacillus megaterium","Bacillus subtilis",
"Trichoderma album","Trichoderma asperellum","Trichoderma viride","Copper complex"]
# raw (case-insensitive, spaces/hyphen-normalized) -> canonical ; typos flagged
TYPO={"1,3 dichloropropene":"1,3-Dichloropropene","lambda-cyhalothyin":"Lambda-cyhalothrin","acetamiprd":"Acetamiprid","bacillus megaterum":"Bacillus megaterium","cayazofamid":"Cyazofamid","cooper oxychloride":"Copper oxychloride",
"cymaxanil":"Cymoxanil","cyproconazde":"Cyproconazole","difenocoazole":"Difenoconazole","diflufenicon":"Diflufenican","etofrnprox":"Etofenprox",
"febuconazole":"Tebuconazole","flufenoxurom":"Flufenoxuron","fludioxanil":"Fludioxonil","fonpyroximate":"Fenpyroximate","kresoxitn-methyl":"Kresoxim-methyl",
"lambd-cyhalothrin":"Lambda-cyhalothrin","lambda - cyhalothyin":"Lambda-cyhalothrin","matalaxyl-m":"Metalaxyl-M","menfentrifluconazole":"Mefentrifluconazole",
"oxamul":"Oxamyl","oxine-coppor":"Oxine-copper","phoshorous acid salts":"Phosphorous acid salts","propamocorb hydrochloride":"Propamocarb hydrochloride",
"sprodiclofen":"Spirodiclofen","trichoderma virde":"Trichoderma viride","fosetyl-aluminam":"Fosetyl-aluminium","fosetyl-aluminicom":"Fosetyl-aluminium",
"thiocyclam hydrogen oxabte":"Thiocyclam hydrogen oxalate"}
def norm(s):
    return " ".join(s.lower().replace("(safener)","").replace(" - ","-").replace("- ","-").replace("tris (","tris(").split())
CANON={norm(k):k for k in list(C)+NULLCAS}
EXTRA={"copper sulfate (tribasic)":"Copper sulfate (tribasic)","copper sulfate anhydrous":"Copper sulfate","copper sulfate pentahydrate":"Copper sulfate pentahydrate",
"copper sulfate":"Copper sulfate","bacillus amyloliquefaciens strain f z b 24":"Bacillus amyloliquefaciens FZB24","bacillus amyloliquefaciens strain fzb24":"Bacillus amyloliquefaciens FZB24",
"bacillus amyloliquefaciens strain mbi 600":"Bacillus amyloliquefaciens MBI 600","orange oil (d-limonene)":"Orange oil","mesosulfuron methyl":"Mesosulfuron-methyl",
"mesosulfuron-methyl sodium":"Mesosulfuron-methyl","thiophanate methyl":"Thiophanate-methyl","metam sodium":"Metam sodium","fosetyl aluminium":"Fosetyl-aluminium",
"fosetyl-aluminium":"Fosetyl-aluminium","fosetyl-aluminium":"Fosetyl-aluminium","lambda-cyhalothrin":"Lambda-cyhalothrin","beta-cyfluthrin":"Beta-cyfluthrin",
"fludioxanil":"Fludioxonil","zeta-cypermethrin":"Zeta-cypermethrin","zeta-cypermethrin":"Zeta-cypermethrin","zeta -cypermethrin":"Zeta-cypermethrin"}
C["Fludioxonil"]="131341-86-1"; CANON[norm("Fludioxonil")]="Fludioxonil"
def resolve(raw):
    n=norm(raw); n2=n.replace("zeta - ","zeta-")
    for k in (n,n2):
        if k in EXTRA: return EXTRA[k],False
        if k in CANON: return CANON[k],False
        if k in TYPO: return TYPO[k],True
    return None,None
def check(cas):
    d=cas.replace("-","");return int(d[-1])==sum((i+1)*int(c) for i,c in enumerate(reversed(d[:-1])))%10

C.update({"Propyzamide":"23950-58-5","Butralin":"33629-47-9","Quizalofop-P-tefuryl":"200509-41-7","Thiobencarb":"28249-77-6",
"Penoxsulam":"219714-96-2","Cyhalofop-butyl":"122008-85-9","Bispyribac-sodium":"125401-92-5","Quinclorac":"84087-01-4",
"Pretilachlor":"51218-49-6","Fenoxasulfone":"639826-16-7","Triclopyr-butotyl":"64700-56-7","Halosulfuron-methyl":"100784-20-1",
"Bensulfuron-methyl":"83055-99-6","Pyrazosulfuron-ethyl":"93697-74-6","Florpyrauxifen-benzyl":"943832-81-3","Mesotrione":"104206-82-8",
"Fluroxypyr-meptyl":"81406-37-3","Propanil":"709-98-8","MCPA":"94-74-6","Fluroxypyr":"69377-81-7","Nicosulfuron":"111991-09-4",
"Isoxaflutole":"141112-29-0","Cyprosulfamide":"221667-31-8","Terbuthylazine":"5915-41-3","Metribuzin":"21087-64-9","Clopyralid":"1702-17-6",
"Thifensulfuron-methyl":"79277-27-3","Rimsulfuron":"122931-48-0","Triclopyr":"55335-06-3","Amicarbazone":"129909-90-6","Imazapic":"104098-48-8",
"Fomesafen":"72178-02-0","Clomazone":"81777-89-1","Imazamox":"114311-32-9","Imazethapyr":"81335-77-5","Aclonifen":"74070-46-5",
"Propaquizafop":"111479-05-1","Diquat dibromide":"85-00-7","Glufosinate ammonium":"77182-82-2","Glyphosate isopropylammonium":"38641-94-0",
"Glyphosate potassium":"70901-12-1","Glyphosate ammonium":"114370-14-8","Glyphosate diammonium":"69254-40-6","Indaziflam":"950782-86-2","Prodiamine":"29091-21-2"})
REVIEW={"Clodinafop-butyl","Pyroxsulfone","Chlorimuron-methyl","Fenoxaprop-P-butyl"}  # printed names not matching a known active -> CAS null, needs visual review
for k in C: CANON[norm(k)]=k
TYPO.update({"penoxulam":"Penoxsulam","bispyribac sodium":"Bispyribac-sodium","bispyribac-soduim":"Bispyribac-sodium","mesotrine":"Mesotrione",
"flumetsulom":"Flumetsulam","bromoxynil-octanoate":"Bromoxynil octanoate","mcpa sodium":"MCPA-sodium","cyprosulfamide (safener)":"Cyprosulfamide",
"glyphosate isopropylammmonium":"Glyphosate isopropylammonium","glyphosate isopropyammionium":"Glyphosate isopropylammonium",
"glyphosate monopotassium":"Glyphosate potassium","glyphosate monopotassium salt":"Glyphosate potassium","glyphosate potassium salt":"Glyphosate potassium"})
for r in REVIEW: TYPO[norm(r)]="__REVIEW__"+r

TYPO.pop(norm("Pyroxsulfone"),None); TYPO[norm("Pyroxsulfone")]="Pyroxasulfone"
C["Pyroxasulfone"]="447399-55-5"; CANON[norm("Pyroxasulfone")]="Pyroxasulfone"
TYPO["thioahatate-methyl"]="__REVIEW__Thioahatate-methyl"
CAND={"Clodinafop-butyl":"105512-06-9 (Clodinafop-propargyl)","Chlorimuron-methyl":"90982-32-4 (Chlorimuron-ethyl)","Fenoxaprop-P-butyl":"71283-80-2 (Fenoxaprop-P-ethyl)","Thioahatate-methyl":"23564-05-8 (Thiophanate-methyl)"}
