import json,csv,os,collections,shutil,re
from cas_table import check
d=json.load(open('merged_raw.json'));cards=d['cards'];acts=json.load(open('actives_raw.json'))
OUT='../final';shutil.rmtree(OUT,ignore_errors=True);os.makedirs(OUT+'/crops')
bycrop=collections.OrderedDict()
for n,c in enumerate(cards,1):
    c['source_order']=n; c.pop('_src',None)
    bycrop.setdefault(c['crop_id'],[]).append(c)
for cid,cs in bycrop.items():
    for i,c in enumerate(cs,1): c['id']=f"{cid}-{c['part']}-{i:02d}"
    json.dump(dict(dataset='apc_recommendations_2025',schema_version=2,crop_id=cid,cards=cs),open(f'{OUT}/crops/{cid}.json','w'),ensure_ascii=False,indent=1)
alist=sorted(acts.values(),key=lambda v:v['name_en'].lower())
json.dump(dict(dataset='actives',note='CAS assigned from reference knowledge + check-digit; not yet matched to PubChem/ECHA. cas=null rows need review.',actives=alist),open(OUT+'/actives.json','w'),ensure_ascii=False,indent=1)
shutil.copy('../chunks/chunk_46_appendix7.json',OUT+'/appendix7_minor_crops.json')
# flat csv
rows=0
with open(OUT+'/recommendations_flat.csv','w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f);w.writerow(['crop_id','part','pest_ar','pest_type','printed_page','actives_and_concentration (CAS)','formulation','rate_text_ar','phi_days','who','mrl_epa|eu|codex','uncertain'])
    for c in cards:
        for t in c['tables']:
            for r in t['recommendations']:
                a=' + '.join(f"{x['name_en']} {x['pct'] if x['pct'] is not None else ''}% [{x['cas'] or 'NO-CAS'}]" for x in r['actives'])
                for o in r['options']:
                    m=' ; '.join(f"{x['epa']}|{x['eu']}|{x['codex']}" for x in o['mrl'])
                    w.writerow([c['crop_id'],c['part'],c['pest_name_ar'],c['pest_type'],(c['printed_pages'] or [''])[0],a,f"{r['formulation_type'] or ''} {r['formulation_total_pct'] or ''}".strip(),o['rate_text_ar'],o['phi_days'],o['who_class'],m,o['uncertain']]);rows+=1
# validation
rep=[];bad=0
for a in alist:
    if a['cas'] and not check(a['cas']): rep.append('BAD CAS '+a['cas']);bad+=1
nocas=[a['name_en'] for a in alist if not a['cas']]
unc_cards=sum(1 for c in cards if c['uncertain']);unc_rows=sum(1 for c in cards for t in c['tables'] for r in t['recommendations'] for o in r['options'] if o['uncertain'])
src_rows=sum(t['source_rows'] for c in cards for t in c['tables']);opt_rows=sum(len(r['options']) for c in cards for t in c['tables'] for r in t['recommendations'])
assert src_rows==opt_rows==rows,(src_rows,opt_rows,rows)
pct=0
for c in cards:
    for t in c['tables']:
        for r in t['recommendations']:
            tot=sum(x['pct'] or 0 for x in r['actives'])
            if r['formulation_total_pct'] and r['actives'] and all(x['pct'] is not None for x in r['actives']) and abs(tot-r['formulation_total_pct'])>0.6: pct+=1
man=dict(dataset='apc_recommendations_2025',source='كتاب التوصيات المعتمدة لمكافحة الآفات الزراعية 2025 (APC)',pages_covered='g14–g363 (cards) + g395–g402 (appendix 7)',
 crops=len(bycrop),cards=len(cards),source_rows=src_rows,recommendations=sum(len(t['recommendations']) for c in cards for t in c['tables']),
 actives=len(alist),actives_without_cas=nocas,bad_check_digits=bad,uncertain_cards=unc_cards,uncertain_rows=unc_rows,pct_sum_mismatch_groups=pct,
 not_extracted='Appendices 1-6 (prose guides, g364-g394), ads/notice g403-g405, images',crop_card_counts={k:len(v) for k,v in bycrop.items()})
json.dump(man,open(OUT+'/manifest.json','w'),ensure_ascii=False,indent=1)
print(json.dumps({k:v for k,v in man.items() if k!='crop_card_counts'},ensure_ascii=False,indent=1));print(len(bycrop))
